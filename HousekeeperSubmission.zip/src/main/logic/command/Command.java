package main.logic.command;

/**
 * @@author A0124719A
 * Provides Housekeeper an interface to execute commands.
 */
public interface Command {
	String execute();
}

